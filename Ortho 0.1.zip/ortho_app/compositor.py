"""
compositor.py — Composes rendered view data (from renderer.py) into a single
output image, using pixel-exact bounding-box layout (NOT matplotlib GridSpec,
which fights aspect-equal scaling across panels of different aspect ratios —
confirmed during earlier development).
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors
from matplotlib.collections import LineCollection

from visibility import project_points


def _view_used_bbox(result, pad_frac=0.05):
    xs, ys = [], []
    for c in result["outer_contours"]:
        xs.extend(c[:, 1]); ys.extend(c[:, 0])
    if result.get("ao_raster") is not None:
        _, alpha = result["ao_raster"]
        rows = np.any(alpha, axis=1)
        cols = np.any(alpha, axis=0)
        if rows.any():
            y_idx = np.where(rows)[0]
            x_idx = np.where(cols)[0]
            ys.extend([y_idx.min(), y_idx.max()])
            xs.extend([x_idx.min(), x_idx.max()])
    pose, xmag, ymag, resolution = result["pose"], result["xmag"], result["ymag"], result["resolution"]
    for p0, p1 in result["edge_segments"]:
        pts = np.array([p0, p1])
        px, py, _ = project_points(pts, pose, xmag, ymag, resolution)
        xs.extend(px); ys.extend(py)
    if not xs:
        return (0, resolution, 0, resolution)
    xs = np.array(xs); ys = np.array(ys)
    w = xs.max() - xs.min(); h = ys.max() - ys.min()
    pad = pad_frac * max(w, h) if max(w, h) > 0 else 1
    return xs.min() - pad, xs.max() + pad, ys.min() - pad, ys.max() + pad


def _rib_used_bbox(rib_segments, ppm, pad_frac=0.05):
    if not rib_segments:
        return (0, 1, 0, 1)
    xs, ys = [], []
    for p0, p1 in rib_segments:
        xs += [p0[0] * ppm, p1[0] * ppm]
        ys += [-p0[1] * ppm, -p1[1] * ppm]
    xs = np.array(xs); ys = np.array(ys)
    w = xs.max() - xs.min(); h = ys.max() - ys.min()
    pad = pad_frac * max(w, h) if max(w, h) > 0 else 1
    return xs.min() - pad, xs.max() + pad, ys.min() - pad, ys.max() + pad


def _draw_view(ax, result, bbox, line_color, bg_color="#FFFFFF",
                lw_outer=0.9, lw_edge=0.55):
    """Draws one view: AO shading as a raster underlay, tinted between the
    background colour and the line colour, then clean line art on top.

    REPLACES the previous AO-as-contour-lines approach. That approach drew
    only the iso-brightness boundary lines and never the shaded regions
    between them — by construction it could only ever look like a
    topographic contour map, never a gradient, regardless of ray count,
    AO level count, or render material settings (all of which were tried
    and correctly ruled out as the cause). The actual fix is structural:
    carry the AO render through as a grayscale raster instead of reducing
    it to contour lines, and paint it as an underlay.

    COLOUR FIX (this round): the raster used to be blended as
    `background_rgb * grayscale` (a plain multiply against the background
    colour only). That is correct ONLY for the black-on-white default,
    where darkening white happens to land on values that look like a
    shaded version of black linework. Confirmed via real user-supplied
    renders that it breaks for any other colour scheme — e.g. blue
    linework on a dark navy background still came out with black/gray AO
    shading, completely disconnected from the line colour, because the
    blend never referenced line_color at all. Fix: interpolate AO shading
    between bg_color (at full brightness, gray=255 -> "fully open, no
    shadow") and line_color (at full occlusion, gray=0 -> "as dark/strong
    as the linework itself"), instead of multiplying against bg_color
    alone. This guarantees the shaded regions always read as a natural
    gradient toward the line colour, matching whatever colour scheme is
    chosen, rather than defaulting to gray/black regardless of it.
    """
    pose, xmag, ymag, resolution = result["pose"], result["xmag"], result["ymag"], result["resolution"]
    xmin, xmax, ymin, ymax = bbox

    if result.get("ao_raster") is not None:
        gray, alpha = result["ao_raster"]
        bg_rgb = np.array(matplotlib.colors.to_rgb(bg_color))
        line_rgb = np.array(matplotlib.colors.to_rgb(line_color))
        gray_norm = gray.astype(float) / 255.0  # 0..1, 1=fully open/bright, 0=fully occluded
        # Linear interpolation per channel: t=1 (open) -> bg_color,
        # t=0 (occluded) -> line_color. Equivalent to the old multiply
        # blend exactly when line_color is black (line_rgb=0 reduces this
        # to gray_norm * bg_rgb), so the default black-on-white look is
        # unchanged; any other line colour now tints correctly instead.
        rgb = gray_norm[:, :, None] * bg_rgb[None, None, :] + (1 - gray_norm[:, :, None]) * line_rgb[None, None, :]
        rgba = np.dstack([rgb, alpha.astype(float)])
        # Raster is in its own (resolution x resolution) pixel space, same
        # convention used elsewhere in this file: row 0 = top, col 0 = left.
        # imshow's default origin matches that, so plot directly with
        # extent mapping pixel index -> (x, y) in the same space the line
        # art below already uses (no flip needed here).
        ax.imshow(rgba, extent=(0, resolution, resolution, 0), interpolation="bilinear", zorder=0)

    outer_segs = [np.column_stack([c[:, 1], c[:, 0]]) for c in result["outer_contours"]]
    if outer_segs:
        ax.add_collection(LineCollection(outer_segs, colors=line_color, linewidths=lw_outer,
                                          capstyle="round", joinstyle="round", zorder=2))

    edge_pts = result["edge_segments"]
    if edge_pts:
        # Project all segment endpoints in one batched call rather than per-segment.
        pts = np.array(edge_pts).reshape(-1, 3)  # (2*N, 3): p0,p1,p0,p1,...
        px, py, _ = project_points(pts, pose, xmag, ymag, resolution)
        px = px.reshape(-1, 2)
        py = py.reshape(-1, 2)
        edge_segs = np.stack([np.column_stack([px[i], py[i]]) for i in range(len(px))])
        ax.add_collection(LineCollection(edge_segs, colors=line_color, linewidths=lw_edge,
                                          capstyle="round", joinstyle="round", zorder=2))

    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymax, ymin)
    ax.set_aspect("equal")
    ax.axis("off")


def _draw_rib(ax, rib_segments, ppm, bbox, line_color, lw=1.0):
    """Same batching fix as _draw_view, applied to rib/cross-section
    segments — these can also number in the thousands on fragmented
    meshes and would hit the identical per-Line2D overhead otherwise."""
    if rib_segments:
        segs = np.array([[[p0[0] * ppm, -p0[1] * ppm], [p1[0] * ppm, -p1[1] * ppm]]
                          for p0, p1 in rib_segments])
        ax.add_collection(LineCollection(segs, colors=line_color, linewidths=lw,
                                          capstyle="round", joinstyle="round"))
    xmin, xmax, ymin, ymax = bbox
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymax, ymin)
    ax.set_aspect("equal")
    ax.axis("off")


RIB_MAX_PER_ROW = 2  # user-requested cap: keeps rib rows close to a
                      # square/rectangle rather than a long thin strip,
                      # minimizing wasted canvas space.


def compose_image(view_results, rib_sections, rib_ppm, output_path,
                   bg_color="#FFFFFF", line_color="#000000",
                   scale_pct=100, dpi_base=150):
    """view_results: dict of {view_name: render_view() result}, only for
    views the user actually requested.
    rib_sections: list of rib cuts, each a list of (p0,p1) segment pairs
    (as returned by renderer.render_rib_sections) — empty list if no rib
    cuts requested. Rib cuts are laid out in a grid, wrapping at
    RIB_MAX_PER_ROW per row (rather than one ever-widening row), so a
    large cut count doesn't tank per-slice resolution on the page.
    rib_ppm: pixels-per-world-unit scale factor for rib cuts (must match
    the same scale used for the orthographic views, for true relative size).
    scale_pct: output resolution scale, 25-100 (matches UI slider).
    """
    bboxes = {}
    sizes = {}
    for name, result in view_results.items():
        bbox = _view_used_bbox(result)
        bboxes[name] = bbox
        sizes[name] = (bbox[1] - bbox[0], bbox[3] - bbox[2])

    GAP = 40

    rib_bboxes = []
    rib_sizes = []
    has_rib = bool(rib_sections)
    if has_rib:
        for segs in rib_sections:
            bbox = _rib_used_bbox(segs, rib_ppm)
            rib_bboxes.append(bbox)
            rib_sizes.append((bbox[1] - bbox[0], bbox[3] - bbox[2]))

    # rows: list of dicts describing what to draw and where. Each row is
    # either a "views" row (one or more named orthographic views side by
    # side) or a "rib" row (one chunk of up to RIB_MAX_PER_ROW rib cuts).
    rows = []  # list of dicts: {kind, height, width, ...}

    has_front = "front" in view_results
    has_back = "back" in view_results
    if has_front or has_back:
        names = [n for n in ("front", "back") if n in view_results]
        w = sum(sizes[n][0] for n in names) + GAP * (len(names) - 1)
        h = max(sizes[n][1] for n in names)
        rows.append({"kind": "views", "names": names, "height": h, "width": w})

    for simple in ["left", "right"]:
        if simple in view_results:
            w, h = sizes[simple]
            rows.append({"kind": "views", "names": [simple], "height": h, "width": w})

    if has_rib:
        # Chunk rib cuts into groups of at most RIB_MAX_PER_ROW, each
        # chunk becoming its own row, so e.g. 7 cuts -> a row of 4 then a
        # row of 3, instead of one row of 7 squeezed into the page width.
        for start in range(0, len(rib_sections), RIB_MAX_PER_ROW):
            chunk_idx = list(range(start, min(start + RIB_MAX_PER_ROW, len(rib_sections))))
            chunk_sizes = [rib_sizes[i] for i in chunk_idx]
            row_h = max(s[1] for s in chunk_sizes)
            row_w = sum(s[0] for s in chunk_sizes) + GAP * (len(chunk_sizes) - 1)
            rows.append({"kind": "rib", "indices": chunk_idx, "height": row_h, "width": row_w})

    # Top/bottom now share one row, side by side (previously two stacked
    # full-width rows) — user-requested, since stacking wasted vertical
    # canvas space when both views together are no wider than one alone.
    top_bottom_names = [n for n in ("top", "bottom") if n in view_results]
    if top_bottom_names:
        w = sum(sizes[n][0] for n in top_bottom_names) + GAP * (len(top_bottom_names) - 1)
        h = max(sizes[n][1] for n in top_bottom_names)
        rows.append({"kind": "views", "names": top_bottom_names, "height": h, "width": w})

    if not rows:
        raise ValueError("No views selected to render.")

    canvas_w = max(r["width"] for r in rows)
    canvas_h = sum(r["height"] for r in rows) + GAP * (len(rows) - 1)

    scale = max(0.1, min(1.0, scale_pct / 100.0))
    dpi = dpi_base * scale

    fig = plt.figure(figsize=(canvas_w / 100, canvas_h / 100), dpi=dpi, facecolor=bg_color)

    def add_axes_px(x0, y0_top, wpx, hpx):
        x_frac = x0 / canvas_w
        w_frac = wpx / canvas_w
        h_frac = hpx / canvas_h
        y0_bottom = canvas_h - y0_top - hpx
        y_frac = y0_bottom / canvas_h
        ax = fig.add_axes([x_frac, y_frac, w_frac, h_frac])
        ax.set_facecolor(bg_color)
        return ax

    y_cursor = 0
    for row in rows:
        row_h, row_w = row["height"], row["width"]
        x_cursor = (canvas_w - row_w) / 2
        if row["kind"] == "views":
            for name in row["names"]:
                w_v, h_v = sizes[name]
                ax = add_axes_px(x_cursor, y_cursor, w_v, row_h)
                _draw_view(ax, view_results[name], bboxes[name], line_color, bg_color)
                x_cursor += w_v + GAP
        elif row["kind"] == "rib":
            for i in row["indices"]:
                w_r, h_r = rib_sizes[i]
                ax = add_axes_px(x_cursor, y_cursor, w_r, row_h)
                _draw_rib(ax, rib_sections[i], rib_ppm, rib_bboxes[i], line_color)
                x_cursor += w_r + GAP
        y_cursor += row_h + GAP

    plt.savefig(output_path, dpi=dpi, facecolor=bg_color)
    plt.close(fig)
    return output_path
