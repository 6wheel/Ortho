"""
app.py — Flask web application for the orthographic template generator.

Run with: python app.py
Then open http://127.0.0.1:5000 in a browser (this also now opens
automatically — see bottom of this file).

This is the "drop a file in, get a picture out" tool described in
STATUS.md. See that file for full project context and decisions.
"""

HOST = "127.0.0.1"
PORT = 5000

import sys
import webbrowser


def _check_dependencies():
    """Checks all required libraries are installed BEFORE attempting the
    real imports below, so a missing one produces a short, plain-English
    message instead of a raw Python traceback (which would be unreadable
    to someone without Python experience)."""
    required = {
        "flask": "flask",
        "trimesh": "trimesh",
        "pyrender": "pyrender",
        "OpenGL": "PyOpenGL",
        "skimage": "scikit-image",
        "numpy": "numpy",
        "scipy": "scipy",
        "collada": "pycollada",
        "matplotlib": "matplotlib",
        "rtree": "rtree",
    }
    missing = []
    for module_name, pip_name in required.items():
        try:
            __import__(module_name)
        except ImportError:
            missing.append(pip_name)

    if missing:
        print("=" * 70)
        print("SETUP NOT FINISHED — some required libraries are missing.")
        print("=" * 70)
        print()
        print("Missing: " + ", ".join(missing))
        print()
        print("To fix this, open a command window in this folder and run:")
        print()
        print("    python -m pip install -r requirements.txt")
        print()
        print("Then try running 'python app.py' again.")
        print("See README.md if you run into trouble.")
        print("=" * 70)
        sys.exit(1)


_check_dependencies()

import os
import json
import uuid

from flask import Flask, request, render_template, jsonify, send_from_directory

from model_loader import load_model, build_filtered_mesh, ModelLoadError, SUPPORTED_EXTENSIONS
from renderer import get_model_scale, detect_front_axis, render_view, render_rib_sections, AxisConfig, compute_ambient_occlusion
from compositor import compose_image

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
SELECTIONS_DIR = os.path.join(BASE_DIR, "selections")
GLOBAL_PREFS_PATH = os.path.join(BASE_DIR, "global_prefs.json")
for d in (UPLOAD_DIR, OUTPUT_DIR, SELECTIONS_DIR):
    os.makedirs(d, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024  # 500MB, generous for big meshes

# In-memory cache of loaded models for this session, keyed by a session id
# we hand back to the browser. Avoids re-parsing the file on every
# checkbox change / regenerate click. NOTE: single-process, single-user
# tool (runs on the user's own machine) -- this is fine; not built for
# concurrent multi-user use.
_MODEL_CACHE = {}


def _selection_path(filename):
    safe_name = "".join(c if c.isalnum() or c in "._-" else "_" for c in filename)
    return os.path.join(SELECTIONS_DIR, safe_name + ".json")


# Global preferences: color, views, scale, AO on/off, orientation defaults.
# Unlike per-file part selections (which only make sense per-model), these
# are user requested to be GLOBAL — one shared set of preferences that
# applies no matter what file is loaded next, not remembered per-filename.
DEFAULT_GLOBAL_PREFS = {
    "views": ["front", "back", "left", "top"],
    "include_rib": False,
    "rib_cuts": 1,
    "bg_color": "#FFFFFF",
    "line_color": "#000000",
    "scale_pct": 100,
    "ao": False,
    "up_axis": "y",
    "front_flip": False,
}


def _load_global_prefs():
    if os.path.exists(GLOBAL_PREFS_PATH):
        try:
            with open(GLOBAL_PREFS_PATH) as fh:
                saved = json.load(fh)
            prefs = dict(DEFAULT_GLOBAL_PREFS)
            prefs.update(saved)
            return prefs
        except Exception:
            pass
    return dict(DEFAULT_GLOBAL_PREFS)


def _save_global_prefs(prefs):
    try:
        with open(GLOBAL_PREFS_PATH, "w") as fh:
            json.dump(prefs, fh)
    except Exception:
        pass  # non-fatal; persistence is a convenience, not a hard requirement


@app.route("/preferences", methods=["GET"])
def get_preferences():
    return jsonify(_load_global_prefs())


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        return jsonify({"error": "No file provided."}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "No file selected."}), 400

    ext = os.path.splitext(f.filename)[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        return jsonify({
            "error": f"Unsupported file type '{ext}'. Supported: "
                     f"{', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        }), 400

    save_path = os.path.join(UPLOAD_DIR, f.filename)
    f.save(save_path)

    try:
        mesh, part_face_ranges = load_model(save_path)
    except ModelLoadError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Unexpected error loading file: {e}"}), 500

    session_id = str(uuid.uuid4())
    _MODEL_CACHE[session_id] = {
        "mesh": mesh,
        "part_face_ranges": part_face_ranges,
        "filename": f.filename,
    }

    # Load saved selection state for this filename, if any.
    sel_path = _selection_path(f.filename)
    saved_excluded = []
    if os.path.exists(sel_path):
        try:
            with open(sel_path) as fh:
                saved_excluded = json.load(fh).get("excluded", [])
        except Exception:
            saved_excluded = []

    part_names = sorted(part_face_ranges.keys())
    return jsonify({
        "session_id": session_id,
        "filename": f.filename,
        "part_names": part_names,
        "excluded": [p for p in saved_excluded if p in part_face_ranges],
        "vertex_count": len(mesh.vertices),
        "face_count": len(mesh.faces),
    })


@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json()
    session_id = data.get("session_id")
    if session_id not in _MODEL_CACHE:
        return jsonify({"error": "Session expired or invalid. Please re-upload the file."}), 400

    cached = _MODEL_CACHE[session_id]
    mesh = cached["mesh"]
    part_face_ranges = cached["part_face_ranges"]
    filename = cached["filename"]

    excluded = set(data.get("excluded", []))
    views = data.get("views", ["front", "back", "left", "top"])
    include_rib = data.get("include_rib", False)
    rib_cuts = max(1, int(data.get("rib_cuts", 1)))
    bg_color = data.get("bg_color", "#FFFFFF")
    line_color = data.get("line_color", "#000000")
    scale_pct = int(data.get("scale_pct", 100))
    ao_enabled = bool(data.get("ao", False))
    up_axis = data.get("up_axis", "y")
    # forward_axis has no UI control of its own (only up_axis is exposed,
    # since for nearly every file tested so far Z-forward was correct once
    # up_axis was set right). Real bug found via user testing: this used to
    # be a hardcoded default of "z" with no relationship to up_axis, so
    # picking "Z" as the up axis (a real, correct choice for some BeamNG
    # mods, which commonly use Z-up unlike the Y-up convention seen in
    # every KN5 file tested so far) collided with the hardcoded forward
    # default and AxisConfig correctly refused with "up_axis and
    # forward_axis must be different" — crashing the render instead of
    # just picking a different, still-sensible forward axis automatically.
    # Fix: only default to "z" when that's actually different from
    # up_axis; otherwise fall back to "y" (the next most common forward-
    # ish convention) and only "x" as a last resort if both are taken.
    requested_forward = data.get("forward_axis")
    if requested_forward:
        forward_axis = requested_forward
    elif up_axis != "z":
        forward_axis = "z"
    elif up_axis != "y":
        forward_axis = "y"
    else:
        forward_axis = "x"
    front_flip = bool(data.get("front_flip", False))

    # Save selection state for next time, keyed by filename (per-model, since
    # which parts are interior/exterior is specific to each model).
    try:
        with open(_selection_path(filename), "w") as fh:
            json.dump({"excluded": sorted(excluded)}, fh)
    except Exception:
        pass  # non-fatal; persistence is a convenience, not a hard requirement

    # Save GLOBAL preferences (colors, views, scale, AO, orientation defaults)
    # — explicitly requested as global, not per-file, unlike the part
    # selections above.
    _save_global_prefs({
        "views": views, "include_rib": include_rib, "rib_cuts": rib_cuts,
        "bg_color": bg_color, "line_color": line_color, "scale_pct": scale_pct,
        "ao": ao_enabled, "up_axis": up_axis, "front_flip": front_flip,
    })

    try:
        filtered = build_filtered_mesh(mesh, part_face_ranges, excluded)
        if len(filtered.faces) == 0:
            return jsonify({"error": "All parts excluded — nothing to render. Untick at least one part."}), 400

        center, half_span, dist = get_model_scale(filtered)
        auto_sign = detect_front_axis(mesh, part_face_ranges, forward_axis=forward_axis)
        front_sign = -auto_sign if front_flip else auto_sign
        axis_cfg = AxisConfig(up_axis=up_axis, forward_axis=forward_axis, front_sign=front_sign)

        base_res = 1800
        render_res = max(400, int(base_res * (scale_pct / 100.0)))

        # AO is a property of the mesh's geometry, not of any one camera
        # angle — compute it ONCE here and reuse the same result for every
        # requested view, rather than recomputing per view (which would be
        # needlessly slow for an identical result).
        ao_mesh = compute_ambient_occlusion(filtered) if ao_enabled else None

        view_results = {}
        for v in views:
            view_results[v] = render_view(
                filtered, v, center, half_span, dist, axis_cfg,
                resolution=render_res, ao_mesh=ao_mesh,
            )

        rib_sections = []
        rib_ppm = 1.0
        if include_rib:
            rib_sections = render_rib_sections(filtered, axis_cfg, n_cuts=rib_cuts)
            rib_ppm = render_res / (half_span * 2)

        out_name = f"{uuid.uuid4()}.png"
        out_path = os.path.join(OUTPUT_DIR, out_name)
        compose_image(
            view_results, rib_sections, rib_ppm, out_path,
            bg_color=bg_color, line_color=line_color, scale_pct=scale_pct,
        )
        return jsonify({"image_url": f"/outputs/{out_name}"})

    except Exception as e:
        return jsonify({"error": f"Render failed: {e}"}), 500


@app.route("/outputs/<filename>")
def serve_output(filename):
    return send_from_directory(OUTPUT_DIR, filename)


if __name__ == "__main__":
    print(f"Detected OS: {sys.platform}")
    print("Starting Orthographic Template Generator...")
    print(f"Open http://{HOST}:{PORT} in your browser.")

    # Automatically open the app in the default browser, so the person never
    # has to manually type the address.
    webbrowser.open(f"http://{HOST}:{PORT}")

    # On macOS, pyrender/pyglet's underlying window/GL machinery is known to
    # crash if touched from a non-main thread ("NSWindow drag regions should
    # only be invalidated on the Main Thread!" — a documented pyglet/macOS
    # issue, confirmed via search, not guessed). Flask's default dev server
    # handles each request on its own thread, which can trigger this on Mac
    # specifically. Disabling threading keeps every render call on the main
    # thread there. Linux/Windows are unaffected and keep threading on.
    app.run(host=HOST, port=PORT, debug=False, threaded=sys.platform != "darwin")
