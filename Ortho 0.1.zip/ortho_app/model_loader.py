"""
model_loader.py — Unified entry point for loading a 3D model file of any
supported format into a clean trimesh.Trimesh, ready for rendering.

Supported formats:
    .obj            - direct trimesh load
    .dae            - direct trimesh load (via pycollada)
    .stl            - direct trimesh load
    .gltf / .glb    - direct trimesh load
    .kn5            - converted via our own from-scratch parser (kn5_reader.py
                       / kn5_to_obj.py) to a temporary OBJ, then loaded normally

Every path strips texture visuals before returning, because trimesh
auto-generates a TextureVisuals object whenever UV coordinates are present
(even with no actual image), and pyrender's texture upload crashes on that
in this environment. We don't need textures for line-art rendering anyway.
"""

import os
import re
import tempfile
import numpy as np
import trimesh

from kn5_to_obj import convert as kn5_convert

SUPPORTED_EXTENSIONS = {".obj", ".dae", ".stl", ".gltf", ".glb", ".kn5"}


class ModelLoadError(Exception):
    pass


def strip_texture_visuals(mesh):
    """Removes any texture/material visual data, replacing with plain
    color visuals. Required before any pyrender render call in this
    environment (see STATUS.md for the crash this avoids)."""
    mesh.visual = trimesh.visual.ColorVisuals(mesh)
    return mesh


def _parse_obj_groups(path):
    """Manually parses an OBJ file's 'o'/'g' group declarations and tracks
    which faces belong to which named group.

    trimesh's scene loader groups faces by MATERIAL, not by the original
    o/g group names, which destroys real per-part names (confirmed: a
    41-group OBJ collapses to ~16 material-based groups under trimesh's
    default loading). This function preserves the real names instead.

    Tolerant of mixed/non-standard line endings and of group lines that
    have a leading space before 'o '/'g ' (both real quirks seen in actual
    exported files during development).
    """
    vertices = []
    groups = {}
    current = "(ungrouped)"
    groups[current] = []

    with open(path, "r", errors="replace") as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            if s[0] == "v" and (len(s) == 1 or s[1] == " "):
                parts = s.split()
                vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
            elif s[0] in ("o", "g") and (len(s) == 1 or s[1] == " "):
                name = s.split(None, 1)[1].strip() if len(s.split(None, 1)) > 1 else "(unnamed)"
                if name not in groups:
                    groups[name] = []
                current = name
            elif s[0] == "f" and (len(s) == 1 or s[1] == " "):
                face_parts = s.split()[1:]
                idx = [int(p.split("/")[0]) - 1 for p in face_parts]
                groups[current].append(idx)

    if not groups.get("(ungrouped)"):
        groups.pop("(ungrouped)", None)

    return np.array(vertices), groups


def load_model(path):
    """Loads any supported 3D model file and returns (mesh, part_face_ranges)
    where part_face_ranges maps {part_name: (face_start_index, face_end_index)}
    against mesh.faces, so the caller can map checkbox selections back to
    actual faces regardless of input format.
    """
    ext = os.path.splitext(path)[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise ModelLoadError(
            f"Unsupported file type '{ext}'. Supported types: "
            f"{', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )

    if ext == ".kn5":
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_obj = os.path.join(tmpdir, "converted.obj")
            try:
                kn5_convert(path, tmp_obj)
            except Exception as e:
                raise ModelLoadError(f"Failed to convert KN5 file: {e}") from e
            return _load_obj_with_real_groups(tmp_obj)

    if ext == ".obj":
        return _load_obj_with_real_groups(path)

    return _load_with_parts(path)


def _load_obj_with_real_groups(path):
    """OBJ-specific path: uses our manual parser to preserve real o/g group
    names (our own KN5->OBJ exporter also writes 'g' lines per part, so this
    path is shared by both native OBJ files and KN5-converted ones)."""
    vertices, groups = _parse_obj_groups(path)
    if len(vertices) == 0:
        raise ModelLoadError("OBJ file contains no vertices.")

    all_faces = []
    part_face_ranges = {}
    face_offset = 0
    for name, faces in groups.items():
        if not faces:
            continue
        all_faces.extend(faces)
        part_face_ranges[name] = (face_offset, face_offset + len(faces))
        face_offset += len(faces)

    if not all_faces:
        raise ModelLoadError("OBJ file contains no faces.")

    mesh = trimesh.Trimesh(vertices=vertices, faces=np.array(all_faces), process=False)
    mesh.remove_unreferenced_vertices()
    strip_texture_visuals(mesh)
    return mesh, part_face_ranges


def _load_with_parts(path):
    """Loads a model and tracks which face-index range belongs to which
    named part/group, so the UI can offer per-part checkboxes regardless
    of input format."""
    ext = os.path.splitext(path)[1].lower()

    try:
        scene_or_mesh = trimesh.load(path, process=False, force='scene')
    except Exception as e:
        raise ModelLoadError(f"Failed to load {ext} file: {e}") from e

    part_face_ranges = {}
    all_vertices = []
    all_faces = []
    vertex_offset = 0
    face_offset = 0

    if isinstance(scene_or_mesh, trimesh.Scene):
        geometries = scene_or_mesh.geometry
        if not geometries:
            raise ModelLoadError("File loaded but contains no mesh geometry.")
        # Apply each geometry's scene-graph transform so parts end up in
        # correct world-space position (matters for any format that uses
        # per-node transforms, e.g. DAE/GLTF scene graphs).
        for node_name in scene_or_mesh.graph.nodes_geometry:
            transform, geom_name = scene_or_mesh.graph[node_name]
            geom = geometries[geom_name]
            verts = trimesh.transform_points(geom.vertices, transform)
            faces = geom.faces + vertex_offset

            all_vertices.append(verts)
            all_faces.append(faces)

            n_faces = len(faces)
            part_name = geom_name if geom_name else node_name
            # Disambiguate duplicate names (some formats reuse geometry across nodes)
            base_name = part_name
            suffix = 1
            while part_name in part_face_ranges:
                part_name = f"{base_name}_{suffix}"
                suffix += 1
            part_face_ranges[part_name] = (face_offset, face_offset + n_faces)

            vertex_offset += len(verts)
            face_offset += n_faces

        import numpy as np
        merged = trimesh.Trimesh(
            vertices=np.vstack(all_vertices),
            faces=np.vstack(all_faces),
            process=False,
        )
    else:
        merged = scene_or_mesh
        part_face_ranges = {"(whole model)": (0, len(merged.faces))}

    merged.remove_unreferenced_vertices()
    strip_texture_visuals(merged)
    return merged, part_face_ranges


def build_filtered_mesh(mesh, part_face_ranges, excluded_parts):
    """Given the full loaded mesh and a set of excluded part names, returns
    a new trimesh.Trimesh containing only the faces from non-excluded parts.
    """
    import numpy as np
    keep_mask = np.ones(len(mesh.faces), dtype=bool)
    for name, (start, end) in part_face_ranges.items():
        if name in excluded_parts:
            keep_mask[start:end] = False

    faces = mesh.faces[keep_mask]
    filtered = trimesh.Trimesh(vertices=mesh.vertices.copy(), faces=faces, process=False)
    filtered.remove_unreferenced_vertices()
    strip_texture_visuals(filtered)
    return filtered
